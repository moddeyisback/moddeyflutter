
const participantes = [
  { nome: 'Adrielly', valor: 0 },
  { nome: 'César', valor: 0 },
  { nome: 'Daniel', valor: 200 },
  { nome: 'Eliandra', valor: 0 },
  { nome: 'Elizel', valor: 0 },
  { nome: 'Eloísa', valor: 0 },
  { nome: 'Érika', valor: 0 },
  { nome: 'Everton', valor: 50 },
  { nome: 'Fabrício', valor: 50 },
  { nome: 'Gabriela', valor: 0 },
  { nome: 'Gabriele', valor: 0 },
  { nome: 'Giovana', valor: 50 },
  { nome: 'Heraldo', valor: 100 },
  { nome: 'João', valor: 0 },
  { nome: 'Karine', valor: 0 },
  { nome: 'Laíssa', valor: 0 },
  { nome: 'Letícia', valor: 100 },
  { nome: 'Lian', valor: 100 },
  { nome: 'Lohanna', valor: 0 },
  { nome: 'Márcio', valor: 0 },
  { nome: 'Mônica', valor: 0 },
  { nome: 'Samara', valor: 0 },
  { nome: 'Samily', valor: 0 },
  { nome: 'Samuel', valor: 100 },
  { nome: 'Wandercley', valor: 200 },
];

function entrar() {
  const nome = document.getElementById('nome').value;
  if (!nome) {
    alert('Digite seu nome');
    return;
  }

  document.getElementById('usuario').textContent = nome;
  document.getElementById('conteudo').classList.remove('oculto');

  const lista = document.getElementById('lista');
  lista.innerHTML = '';

  participantes.forEach(p => {
    const div = document.createElement('div');
    div.className = p.valor > 0 ? 'pago' : 'devendo';
    div.innerHTML = `<strong>${p.nome}</strong><br>Valor: R$${p.valor}<br>Status: ${p.valor > 0 ? 'Pago' : 'Devendo'}`;
    div.onclick = () => {
      if (p.valor > 0) {
        document.getElementById('pixArea').classList.remove('oculto');
      }
    };
    lista.appendChild(div);
  });
}

function copiarPix() {
  const pix = document.getElementById('pixCode').textContent;
  navigator.clipboard.writeText(pix).then(() => {
    alert("Código Pix copiado!");
  });
}
